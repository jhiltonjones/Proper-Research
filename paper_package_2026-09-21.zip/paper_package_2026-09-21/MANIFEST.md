# Magnetic beam-steering control study — paper package (2026-09-21)

Matched-authority inverse-Jacobian (INV-7) vs receding-horizon MPC, live on
a UR10e + electromagnet + camera-tracked soft magnetic composite beam.
Every run in this package uses the same frame-corrected harness, the same
`|u_q|<=0.1 rad/s`, `|u_L|<=2mm/s` actuator limits, the same delay-aware
(d=2) preview, and the same normalized-DLS matched-authority inverse
controller (`kp=1`, validated against a small offline sweep — see
`01_rectangle/supplementary/inv7_kp_fairness_sweep.txt`). n=5 live reps per
condition unless noted otherwise.

## Status: 3 shapes with complete or near-complete data

| shape | INV7-FJ | INV7-SJ | MPC-FJ | MPC-SJ | status |
|---|---|---|---|---|---|
| **Rectangle** (10x15mm) | n=5 | n=5 | n=5 | n=5 | complete 2x2, plus full INV-6 baseline + deep mechanism analysis |
| **Triangle** (25mm base, bimaterial) | n=5 | n=5 | n=5 | n=5 | complete 2x2 |
| **U-shape** (10x15mm, bimaterial) | n=5 | n=5 | **NA** (2 diverged) | n=5 | 3/4 cells; MPC-FJ is a genuine failure mode, not missing data |

Two more shapes were started but are NOT in this package (data not yet
sufficient for a paper claim):
- **Triangle 20mm** (original, non-widened base): only n=1-2 per condition,
  early numbers looked like a near-tie/INV-7-edge but that read did not
  survive to n=5 on the 25mm-base triangle (see `02_triangle_25mm/` — treat
  the 20mm triangle as superseded by the 25mm-base result, not as a fourth
  data point).
- **S-curve** (10x20mm, bimaterial): only n=1 SJ pilot. Not included.

## Folder structure

```
01_rectangle/
  figures/        <- MAIN figures: matched-authority INV-7 vs MPC (consistent
                     comparison with the other 2 shapes)
  tables/         <- run_level_summary_INV7_matched.{csv,md} is the one to
                     cite alongside triangle/ushape; run_level_summary_INV6.md
                     is the original (superseded) joint-only-inverse baseline
  supplementary/  <- (a) the original INV-6 4-condition figures/table (shows
                     the actuator-authority confound this whole investigation
                     started from), and (b) the deep mechanism analysis that
                     explains WHY MPC wins: actuator authority, Jacobian
                     staleness, disturbance persistence, horizon length,
                     clipping, kp fairness -- see supplementary/README.md
02_triangle_25mm/
  figures/        <- MAIN: factorial + interaction plots only (full 2x2)
  supplementary/  <- mechanism-figure 4-panel deep dive (SJ, FJ) -- see the
                     rectangle hierarchy note: triangle's role is checking
                     generalization, not a second full mechanism deep dive
  tables/         <- full 2x2, same structure as rectangle's main tables
03_ushape/
  figures/        <- MAIN: factorial plot + the SJ mechanism figure only
  supplementary/  <- the INV7-FJ-vs-schedule mechanism figure (the FJ
                     condition itself is a robustness/failure-mode story,
                     not the primary comparison)
  tables/         <- 3 valid conditions + MPC-FJ_excluded_notes.md
                     explaining the NA cell + partial_contrasts.md
```

## Terminology note (applies throughout this package)

**`Delta_law` is reserved for the factorial average** (MPC-INV7 averaged
over both FJ and SJ). **`Delta_law|SJ`** ("SJ simple effect") is the
matched-authority comparison under the scheduled Jacobian specifically —
this is the more important primary comparison for the paper, because SJ is
the intended, valid operating model; FJ is a model-mismatch robustness
stress test, not a second "equal" arm of the design. Quoting a factorial
average as "MPC's law advantage" overstates the effect under the actual
scheduled controller (worst on the rectangle: factorial −0.800mm vs the
true SJ simple effect of −0.240mm). Every shape's table now has both,
clearly labeled — see each shape's `tables/*.md`.

## Headline result across all 3 shapes

Under matched authority and a scheduled Jacobian (the intended operating
condition), MPC gives lower mean RMS on all three geometries, using
substantially less normalized effort:

| shape | INV7-SJ RMS | MPC-SJ RMS | Delta_law\|SJ | RMS reduction | E_u: INV7-SJ | E_u: MPC-SJ | effort reduction |
|---|---|---|---|---|---|---|---|
| Rectangle | 0.784mm | 0.544mm | −0.240mm | 30.6% | 0.625 | 0.369 | 41% |
| Triangle 25mm | 0.624mm | 0.556mm | −0.067mm | 10.8% | 0.675 | 0.282 | 58% |
| U-shape | 0.560mm | 0.490mm | −0.069mm | 12.4% | 0.606 | 0.216 | 64% |

**A second, arguably stronger, cross-shape result: constraint-limit
activity.** Under SJ, INV-7 hits a joint rate limit on ~16-17% of samples on
*all three* shapes, while MPC is at ~0-1%:

| shape | P(joint rate limit), INV7-SJ | P(joint rate limit), MPC-SJ | P(insertion limit), INV7-SJ | P(insertion limit), MPC-SJ |
|---|---|---|---|---|
| Rectangle | 16.3% | 0.22% | 44.7% | 22.8% |
| Triangle 25mm | 16.5% | 0.81% | 49.0% | 28.2% |
| U-shape | 17.2% | 0.09% | 46.5% | 27.0% |

MPC simultaneously has lower RMS, lower normalized effort, AND far less
constraint-limit activity — a very consistent behavioral difference: MPC
produces considerably less aggressive, less constraint-active control while
obtaining better tracking. (This does NOT by itself prove constraint
anticipation *causes* the tracking improvement — large post-clipping
task-direction rotation was explicitly ruled out as the dominant rectangle
mechanism, see item 3 below — but it's a strong, reproducible system-level
finding worth highlighting on its own.)

Under a frozen (stale) Jacobian, MPC is *usually* far more robust than the
inverse, but not uniformly: rectangle INV-7 degrades 2.65x (FJ/SJ) vs MPC's
1.31x; triangle INV-7 degrades 1.20x vs MPC's essentially-flat 1.04x
(corrected from an earlier draft that said "both degrade mildly, ~1.2x
each" — MPC is close to flat on the triangle, not similarly degraded); on
the U-shape, MPC fails outright (diverges, safety-terminated) while INV-7
degrades but stays bounded. See `03_ushape/tables/MPC-FJ_excluded_notes.md`.

## Recommended paper structure (evidence-strength hierarchy)

**Primary experimental result:** under matched authority and scheduled J,
MPC gives lower mean RMS on rectangle, triangle, and U-shape, while using
substantially less normalized effort and far less actuator-limit activity
(the two headline tables above).

**Robustness experiment:** freezing J severely hurts INV-7 on rectangle and
U-shape, mildly hurts it on triangle; MPC is comparatively robust on
rectangle/triangle but exhibits a reproducible safety-terminating failure on
U-shape. Robustness to model staleness is substantial but not universal.

**Mechanism deep dive — rectangle only:** INV-6→INV-7 establishes the
authority confound; normalized-Jacobian-direction rotation explains the
inverse's FJ lateral vulnerability; clipping is not dominant; constant-
disturbance augmentation is important; horizon length beyond the minimum
causal N=3 contributes only modestly. Do not expect every mechanism metric
to replicate identically on every geometry — it doesn't, and trying to force
that is a weaker story than a focused rectangle deep-dive plus a triangle/
U-shape generalization check.

**Two things that looked like general mechanisms but are NOT (demote to
supplementary, don't use as cross-shape evidence):**
- **Prediction-realization correlation** (mechanism-figure Panel 3):
  supports the MPC story on rectangle-SJ (r_MPC=0.45 vs r_INV7=0.24) but
  *reverses* on triangle-SJ (r_MPC=0.26 vs r_INV7=0.43) and triangle-FJ
  (0.13 vs 0.34); on U-FJ, INV-7's correlation is higher than its own SJ
  value despite much worse tracking. This is a real per-condition
  diagnostic, but not a cross-shape explanation of controller quality —
  each controller is evaluated on the states it created itself, so this
  isn't a pure policy comparison from a common initial state. The
  same-state counterfactual replays (e.g. the insertion-limit sweep, the
  manipulability-ablation A/B/C replay) are stronger causal evidence
  because they hold the state fixed across conditions. The same caveat
  applies to mean Delta-E_chosen,+3 (triangle MPC has *more negative*
  values than INV-7 despite tracking better).
- **Corner vs. straight RMS segmentation**: useful descriptively on the
  rectangle, does not generalize. U-shape INV7-FJ has corner=1.07mm,
  straight=2.06mm despite the problem visibly starting at a corner — error
  from a bad transition persists into the following straight segment, so
  "straight error" isn't necessarily caused by straight-path geometry. The
  triangle has several cases where corner RMS is lower than straight RMS.
  Use corner/straight segmentation only for the rectangle mechanistic
  discussion; if a cross-shape version is needed, use event-aligned
  pre-corner/transition/post-corner windows instead, not a global
  corner-vs-straight split.

## What's established vs still open (evidence hierarchy, see rectangle/supplementary)

1. **Actuator authority** (matched authority via INV-7's normalized-DLS
   7th channel) explains a large part of the ORIGINAL (INV-6 vs MPC)
   advantage -- see `01_rectangle/tables/run_level_summary_INV6.md` vs
   `run_level_summary_INV7_matched.md`.
2. **Jacobian staleness** explains the FJ lateral failure of the inverse
   law specifically (direct DLS inversion of a stale J) --
   `01_rectangle/supplementary/jacobian_geometry_drift.txt`.
3. **Constraint clipping** is NOT the dominant mechanism for the inverse's
   FJ failure (median rotation 1.6-2.9deg, wrong-sign correlation with the
   error) -- `01_rectangle/supplementary/clip_angle_diagnostic.txt`.
4. **Disturbance persistence** (beta_d=1) has a large effect on MPC's
   near-term (+3) prediction quality, both under SJ and FJ --
   `01_rectangle/supplementary/beta_disturbance_persistence_ablation.txt`.
   Caveat: this is offline counterfactual evidence (single-tick replay
   against real states), not a measured live RMS effect.
5. **Horizon length**: most of MPC's advantage is present already at N=3
   (the minimum causal horizon at d=2 delay); a smaller, real,
   monotonically-saturating benefit continues to N=10 --
   `01_rectangle/supplementary/horizon_sweep_analysis.txt` and
   `horizon_u0_agreement.png`. NOT YET ISOLATED as a standalone
   "N=3-only QP vs DLS" live comparison.
6. **Insertion feedback specifically** (vs MPC with u_L pinned to
   feedforward) contributes a real but SMALL slice of MPC's advantage
   (~0.04-0.10mm out of ~0.67mm total SJ gap on the rectangle) --
   `01_rectangle/supplementary/mpc_insertion_feedback_ablation_h3.txt` /
   `_h10.txt`.
7. **Manipulability/authority-shaping secondary objective** (alternative to
   the validated `Q_N` reference-nullspace regularizer) was investigated and
   CLOSED as a negative result: the nonlinear authority landscape is real and
   exploitable, but its reference-linearized first-order QP surrogate
   mispredicts the sign of the true authority change in 40-43% of replayed
   ticks (a curvature/step-size failure, NOT gradient staleness -- directly
   tested and rejected), and increasingly degrades tracking (+90% E_chosen
   at +10 steps) and effort (+163%) as its weight increases. `Q_N` was
   retained. Full record, including regression tests, weight calibration,
   the A/B/C replay, and the staleness-rejection diagnostic:
   `01_rectangle/supplementary/manipulability_ablation/README.md`.

## Figure presentation notes (from the 2026-09-22 review pass)

- `01_rectangle/figures/interaction_plot_extended.png` was regenerated to
  fix mislabeling INV-6/INV-7 as "3 laws" (they're variants of the same
  normalized-DLS/inverse law at different feedback authority, not distinct
  controller laws) -- title now reads "controller/authority variant x
  Jacobian schedule".
- Mechanism-figure Panel 4 was regenerated across all 3 shapes to show BOTH
  conditions' actuator allocation (previously only the MPC condition was
  shown in a figure titled "MPC vs INV-7").
- Mechanism-figure Panels 1/2/4 x-axes were regenerated as normalized path
  progress (%) instead of raw reference index, for cross-shape
  comparability (rectangle N_REF=265, triangle N_REF=288, U-shape N_REF=213
  -- raw indices aren't comparable across shapes).
- Per the hierarchy above, triangle and U-shape mechanism figures (the
  4-panel deep-dive plots) have been moved to
  `02_triangle_25mm/supplementary/` and `03_ushape/supplementary/`
  respectively -- keep the rectangle as the sole mechanistic deep dive in
  the main figures, per the recommended structure above.
- Still open (not done in this pass, flagged for whoever builds final
  manuscript figures): (1) a spatial-task figure showing the actual
  commanded path + mean realized trajectory for each shape -- currently a
  reader never sees the geometry itself, only derived metrics; (2)
  systematic shared y-axis limits between the FJ/SJ mechanism-figure pair
  within each shape (Panel 3 already uses fixed [-2,2] limits; Panels 1/2/4
  still auto-scale per condition, which makes magnitude comparison harder).

## Known caveats to carry into the paper

- E_u is dimensionless/normalized (S_u^-1-scaled), NOT millimetres -- label
  it correctly (flagged explicitly during the investigation, now consistent
  across all tables in this package).
- The disturbance-persistence (beta_d) finding is offline-replay evidence,
  not a live closed-loop measurement -- state it as "strong offline
  mechanistic evidence," not a measured effect size.
- Every quantitative table in this package is regenerated directly from the
  saved `*_run_level_summary.pkl` files (single source of truth) via a
  short script, not manually transcribed -- if you need to re-verify or add
  a metric, edit the summary pkl generation, not the tables by hand.
- The 20mm-base triangle and S-curve results are explicitly NOT in this
  package (insufficient n) -- do not resurrect the early n=1-2 numbers into
  the paper without collecting to n=5 first, since the 25mm-base triangle
  result already demonstrated that small-n reads on this system can flip
  sign as more reps come in.
