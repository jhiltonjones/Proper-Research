# Table 1 — Primary result: matched-authority INV-7 vs MPC, scheduled J (n=5 each)

| Shape | INV-7 RMS (mm) | MPC RMS (mm) | RMS reduction | INV-7 E_u | MPC E_u | Effort reduction |
|---|---:|---:|---:|---:|---:|---:|
| Rectangle | 0.784 | 0.544 | 30.6% | 0.625 | 0.369 | 41% |
| Triangle 25mm | 0.624 | 0.556 | 10.8% | 0.675 | 0.282 | 58% |
| U-shape | 0.560 | 0.490 | 12.4% | 0.606 | 0.216 | 64% |

E_u is dimensionless (S_u^-1-normalized total actuator effort), not
millimetres. Source: `*_run_level_summary.pkl`, condition keys `INV7-SJ` /
`MPC-SJ`. Cross-referenced against Figure 2 (same underlying data,
including the P(joint rate limit active) panel, ~16-17% INV-7 vs ~0-1% MPC
on all three shapes — not repeated in this table, see Figure 2).
