# Table 2 — Model-mismatch (frozen-J) robustness: INV-7 vs MPC

| Shape | INV-7 FJ/SJ RMS ratio | MPC FJ/SJ RMS ratio |
|---|---:|---:|
| Rectangle | 2.65 | 1.31 |
| Triangle 25mm | 1.20 | 1.04 |
| U-shape | 3.49 | NA — safety-terminated (2/2 trials) |

Ratio = FJ RMS / SJ RMS for the same controller; >1 means the frozen
Jacobian degrades tracking relative to the scheduled Jacobian. MPC is more
robust to a frozen Jacobian on rectangle and triangle (ratio closer to 1)
but fails outright on the U-shape rather than degrading gracefully — see
`03_ushape/tables/MPC-FJ_excluded_notes.md`. On the triangle, MPC is close
to flat (1.04x) while INV-7 still degrades meaningfully (1.20x) — do not
read this as "both degrade mildly, ~1.2x each" (a prior draft error,
corrected 2026-09-22).
