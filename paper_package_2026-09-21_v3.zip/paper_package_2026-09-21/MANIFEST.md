# Magnetic beam-steering control study — paper package (2026-09-21, restructured 2026-09-22)

Matched-authority inverse-Jacobian (INV-7) vs receding-horizon MPC, live on
a UR10e + electromagnet + camera-tracked soft magnetic composite beam.
Every run uses the same frame-corrected harness, the same
`|u_q|<=0.1 rad/s`, `|u_L|<=2mm/s` actuator limits, the same delay-aware
(d=2) preview, and the same normalized-DLS matched-authority inverse
controller (`kp=1`, validated — see
`01_rectangle/supplementary/inv7_kp_fairness_sweep.txt`). n=5 live reps per
condition unless noted otherwise. **INV-6 (joint-only feedback, the
original/confounded baseline) appears ONLY in supplementary S1, to justify
why INV-7 is used as the baseline everywhere else — it is not a main-paper
competitor.**

## Status

| shape | INV7-FJ | INV7-SJ | MPC-FJ | MPC-SJ | status |
|---|---|---|---|---|---|
| **Rectangle** (10x15mm) | n=5 | n=5 | n=5 | n=5 | complete 2x2, plus full mechanism analysis |
| **Triangle** (25mm base, bimaterial) | n=5 | n=5 | n=5 | n=5 | complete 2x2 |
| **U-shape** (10x15mm, bimaterial) | n=5 | n=5 | **NA** (2 safety-terminated) | n=5 | 3/4 cells; MPC-FJ is a genuine failure mode |

NOT in this package (insufficient n, do not resurrect without collecting to
n=5): 20mm-base triangle (superseded by 25mm-base), S-curve (n=1 pilot).

## Package structure

```
00_main/            <- MAIN PAPER figure/table set (Fig 2-5, Table 1-2; see below)
01_rectangle/
  supplementary/    <- S1 + rectangle-specific mechanism/ablation detail (S2, S5-S10)
  tables/           <- full run-level numeric tables (INV6 + INV7-matched)
02_triangle_25mm/
  supplementary/    <- S3: full factorial x/y detail + mechanism deep-dive
  tables/
03_ushape/
  supplementary/    <- S4: full factorial x/y detail + mechanism deep-dive
  tables/           <- + MPC-FJ_excluded_notes.md, partial_contrasts.md
```

## Main paper figure/table set (00_main/)

**Figure 1 — System + paths: NOT built.** Needs a photo/schematic of the
physical rig plus the three commanded paths (and ideally mean realized
INV-7-SJ/MPC-SJ trajectories overlaid) — this requires either a real photo
of the setup or hand-built CAD/diagram assets neither generated nor
available in this session; build separately.

**Figure 2** (`Figure2_cross_shape_SJ_performance.png`) — the headline
result. 3 panels (RMS error, normalized feedback effort E_u, fraction of
ticks with joint-rate constraint active, shown as %), grouped by shape,
INV7-SJ (hatched) vs MPC-SJ (solid), individual points + mean±95% CI. Read
straight off this figure:

> With matched feedback authority and scheduled Jacobians, MPC achieves
> lower mean tracking error on all three paths while using substantially
> less normalized effort and much less joint-rate-constraint activity.

Because the triangle/U-shape effects are much smaller than the rectangle's,
the cross-shape claim should be stated as: "MPC produced lower mean
scheduled-J RMS error on all three tested geometries, with a large effect
on the rectangle and smaller effects on the triangle and U-shape" — not as
three independent proofs of the same effect size. If the run ordering
supports it, a run-level hierarchical/block-aware model across the three
geometries would strengthen this beyond the current per-shape n=5 CIs.

**Figure 3** (`Figure3_FJ_SJ_robustness.png`) — model-mismatch robustness,
INV-7 vs MPC only (no INV-6), RMS only, one panel per shape, now with
individual-run points and mean±95% CI at every FJ/SJ endpoint (not just a
mean line) — this matters most for U-shape INV7-FJ, whose apparent
1.95→0.56mm line would otherwise look far more precise than the underlying
dispersion ([0.84, 1.37, 1.48, 1.56, 4.52]mm) really is. U-shape's MPC-FJ
arm is an explicit "MPC-FJ: safety-terminated (2/2 trials)" text
annotation, not a fabricated data point, and the U-shape legend has an
explicit "MPC (SJ only)" entry (previously missing).

**Figure 4** (`Figure4_rectangle_mechanism.png`) — rectangle mechanism deep
dive, restructured into ONE consolidated 2x2 figure per the 2026-09-22
review round 2:
- Panel A: SJ tracking error vs path progress (MPC-SJ vs INV7-SJ).
- Panel B: FJ tracking error vs path progress (MPC-FJ vs INV7-FJ).
- Panel C: **FJ-only** θ_Jy(k) — directional rotation (degrees) of the
  normalized joint-to-y Jacobian row vs its frozen (k=0) value, overlaid
  with |e_y|(INV7-FJ) − |e_y|(MPC-FJ). Renamed from φ_y (avoids clashing
  with the manipulability-ablation's φ authority utility in S10). **The SJ
  version of this panel was dropped**: under SJ, INV-7 uses J(k), not J(0),
  so rotation away from J(0) is not a model error for INV7-SJ — at most it
  would mean "harder regions have more Jacobian variation," not "rotation
  explains the SJ gap." The FJ panel is conceptually sound because J(0) IS
  the (mismatched) model INV-7-FJ actually uses. Both curves visibly co-rise
  from ~40% path progress and peak around 80-85%.
- Panel D: the corrected directional-reliability statistic — P(useful_y>0)
  (bars) and η_y,net (diamonds, signed aggregate mm of net useful
  y-correction per unit joint effort) — for **all four** conditions
  (INV7-SJ, MPC-SJ, INV7-FJ, MPC-FJ), with individual-run points for BOTH
  metrics (a prior draft only showed points for P(useful_y>0)). On FJ:
  INV7=0.54/0.03 vs MPC=0.82/0.16 — MPC's joint corrections are far more
  often genuinely useful in y, not just larger.
- Old Panel 2 (axis-resolved x/y mean error) moved to
  `01_rectangle/supplementary/supp_axis_resolved_error.png`. The ORIGINAL
  Panel 3 (prediction-vs-realization scatter) and Panel 4 (MPC-only
  actuator-decomposition traces) remain in
  `01_rectangle/supplementary/mechanism_figure_INV7_{SJ,FJ}_original_panels3-4.png`
  (S6/S7) — demoted because prediction-realization correlation does NOT
  consistently track controller performance across shapes (see caveats).

**Figure 5** (`Figure5_disturbance_horizon_ablations.png`) — two
controller-mechanism ablations, both **offline counterfactual replay of the
same 5 recorded live trajectories** (stated explicitly in the figure title
— NOT 5+5 new live trials):
- Panel A ("persistent output-disturbance prediction ablation"): a PAIRED
  dot/line plot — each of the 5 recorded trajectories connects
  β_d=0→β_d=1, shown separately for SJ and FJ (accurately reflects the
  paired-replay design; a bar chart would not). Large, consistent benefit
  (SJ: 1.65→0.38mm; FJ: 4.01→0.48mm).
- Panel B (horizon saturation): median cosine agreement of u_q,0 at
  N=3/5/10 with N=15, plus P(useful_y>0) per horizon, now annotated with
  the fraction of ticks whose N=3 command is OPPOSITE-sign to N=15's
  (4.5% at N=3, 0.9% at N=5, 0% at N=10) — the median (0.97 at N=3) alone
  would understate this tail. N=5 is already close to N=15 (median
  cos=0.995); N=10≈N=15. Supports N=3 (the minimum causal horizon at d=2)
  already capturing most of the benefit, with a smaller further gain out to
  N=10 — but not "essentially no difference at N=3," which the median alone
  could wrongly suggest.

**Table 1** (`Table1_primary_SJ_results.md`) — shape × {INV-7 RMS, MPC RMS,
INV-7 E_u, MPC E_u}, mean ± SD, + reduction percentages.

**Table 2** (`Table2_FJ_SJ_robustness_ratio.md`) — shape × {INV-7 FJ/SJ
ratio, MPC FJ/SJ ratio}, U-shape MPC cell marked "NA — both attempted FJ
trials safety-terminated" (not phrased as an estimated probability).

## Terminology note (applies throughout)

**`Delta_law` is reserved for the factorial average** (MPC-INV7 averaged
over both FJ and SJ). **`Delta_law|SJ`** ("SJ simple effect") is the
matched-authority comparison under the scheduled Jacobian specifically —
the more important primary comparison, because SJ is the intended, valid
operating model; FJ is a model-mismatch robustness stress test, not a
second "equal" arm of the design. Quoting a factorial average as "MPC's law
advantage" overstates the effect under the actual scheduled controller
(worst on the rectangle: factorial −0.800mm vs the true SJ simple effect of
−0.240mm). Per-shape simple-effects tables are in each shape's `tables/*.md`.

## Supplementary map (S1-S10)

- **S1** `01_rectangle/supplementary/S1_authority_ladder.png` — INV-6 →
  INV-7 → MPC. The ONE place INV-6 appears; justifies using INV-7 as the
  baseline everywhere else. One-sentence version for the main text: "Giving
  the inverse controller insertion feedback reduced rectangle SJ RMS from
  1.213 to 0.784mm; all subsequent comparisons therefore use the
  matched-authority INV-7 baseline." Also: `interaction_plot.png` and
  `run_level_summary_INV6.md` (the pre-authority-fix 4-condition baseline).
- **S2-S4** full per-shape factorial x/y-RMS detail (superseded as the
  main headline by Figure 2/3, kept for mechanistic detail):
  - S2: `01_rectangle/supplementary/factorial_main_figure.png` (now INV-7,
    not INV-6) + `interaction_plot_INV7_vs_MPC_xy_detail.png` (x/y-RMS
    breakdown, INV-7 vs MPC only).
  - S3: `02_triangle_25mm/supplementary/factorial_main_figure_tri25.png` +
    `interaction_plot_tri25.png`.
  - S4: `03_ushape/supplementary/factorial_main_figure_ushape.png`.
- **S5** `01_rectangle/supplementary/clip_angle_diagnostic.txt` +
  `inv7_clip_diagnostic.png` — constraint clipping is NOT the dominant
  mechanism for the inverse's FJ failure.
- **S6-S7** `01_rectangle/supplementary/mechanism_figure_INV7_{SJ,FJ}_original_panels3-4.png`
  — the original prediction-realization scatter (S6) and MPC-only actuator
  allocation traces (S7), i.e. Figure 4's superseded Panels 3-4, kept for
  reference. Also triangle/U-shape's own full 4-panel mechanism figures
  (`02_triangle_25mm/supplementary/mechanism_figure_tri25_*.png`,
  `03_ushape/supplementary/mechanism_figure_ushape_*.png`) — these still use
  the ORIGINAL Panel 3/4 design (not the Figure-4 replacement), since the
  φ_y(k)/directional-reliability rebuild was only done for the rectangle
  (where the mechanism was established).
- **S8** corner/straight RMS columns in each shape's `tables/*.md` — useful
  descriptively on the rectangle, does NOT generalize (U-shape INV7-FJ:
  corner=1.07mm, straight=2.06mm, despite the problem visibly starting at
  the corner — error from a bad transition persists into the following
  straight segment; triangle has cases where corner RMS is LOWER than
  straight RMS). Don't use as a cross-shape claim.
- **S9** `01_rectangle/supplementary/inv7_kp_fairness_sweep.txt` — INV-7's
  kp=1 gain validated against a small offline sweep.
- **S10** `01_rectangle/supplementary/manipulability_ablation/README.md` —
  manipulability/authority-shaping MPC secondary objective, investigated
  and CLOSED as a negative result (2026-09-22): the nonlinear authority
  landscape is real and exploitable, but its reference-linearized
  first-order QP surrogate mispredicts the sign of the true authority
  change in 40-43% of replayed ticks (a curvature/step-size failure, not
  gradient staleness — directly tested and rejected), and increasingly
  degrades tracking (+90% E_chosen at +10 steps) and effort (+163%) as its
  weight increases. The validated `Q_N` reference-nullspace regularizer was
  retained; the live controller was never modified. Suggested one-sentence
  main-text version: "We also investigated replacing reference-nullspace
  regularization with a projected log-volume authority reward. Although the
  nonlinear authority metric possessed exploitable nullspace gradients
  along the nominal trajectory, its reference-linearized first-order
  surrogate frequently mispredicted the sign of the true authority change
  in replay and increased tracking error and control effort as its weight
  increased. We therefore retained the reference-nullspace regularizer."

Also in `01_rectangle/supplementary/` but not separately numbered above:
`supp_axis_resolved_error.png` (Figure 4's demoted old Panel 2, x/y mean
error vs path progress, SJ and FJ side by side),
`jacobian_geometry.png`/`jacobian_geometry_drift.txt` (Jacobian-schedule
deviation from frozen, the raw-data basis for Figure 4's Panel C),
`beta_disturbance_persistence_ablation.txt`/`horizon_sweep_analysis.txt`/
`horizon_u0_agreement.png` (raw data basis for Figure 5),
`directional_reliability_v2.{png,txt}` (raw data basis for Figure 4 Panel
D), `mpc_insertion_feedback_ablation_h{3,10}.txt`,
`raw_vs_normalized_pinv_diagnostic.txt`, `unit_tests_inv7.txt`,
`inv7_vs_inv6_offline_replay_{FJ,SJ}.txt`.

## Known caveats to carry into the paper

- E_u is dimensionless/normalized (S_u^-1-scaled), NOT millimetres.
- The disturbance-persistence (Figure 5 Panel A) and horizon-saturation
  (Panel B) findings are offline same-state counterfactual replay evidence,
  not live closed-loop measurements — state as "offline mechanistic
  evidence," not a measured effect size.
- Prediction-realization correlation (the ORIGINAL Panel 3, now S6/S7) does
  NOT consistently track controller performance across shapes: rectangle-SJ
  supports the MPC story (r_MPC=0.45 vs r_INV7=0.24) but triangle-SJ
  reverses it (r_MPC=0.26 vs r_INV7=0.43), as does triangle-FJ (0.13 vs
  0.34); on U-FJ, INV-7's correlation is higher than its own SJ value
  despite much worse tracking. Each controller is evaluated on states it
  created itself, so this isn't a pure policy comparison from a common
  initial state — the same-state counterfactual replays (Figure 5,
  insertion-limit sweep, manipulability A/B/C) are stronger causal evidence.
- Corner-vs-straight RMS segmentation (S8) does not generalize past the
  rectangle — see S8 above.
- U-shape MPC-FJ: report as "both attempted trials developed rapidly
  increasing error in the same path region and were safety-terminated;
  therefore no complete-path RMS is reported" — do NOT imply a measured
  failure probability from n=2 attempts. The rectangle-triangle-U-shape
  co-localization of INV7-FJ/MPC-FJ trouble at the same path region is a
  **failure-location observation**, not an independent demonstration of the
  Jacobian-rotation root-cause mechanism (that mechanism — Figure 4 Panel C
  — was established rigorously only on the rectangle, and only for the FJ
  condition specifically, not SJ — see Figure 4's description above).
- U-shape INV7-FJ has high dispersion (mean±sd 1.95±1.31mm from per-run
  values [0.84, 1.37, 1.48, 1.56, 4.52]mm) — one outlier run dominates the
  mean; median is 1.48mm. Keep individual points visible in any figure
  using this condition.
- Triangle: MPC-SJ vs INV7-SJ (−0.067mm) is a real but much smaller effect
  than the rectangle (−0.240mm); with n=5 the per-condition 95% CIs
  visibly overlap — don't oversell statistically. If the trial structure
  supports paired/block-aware inference, prefer that over treating the 10
  runs as independent groups. The schedule effect is asymmetric: INV-7
  benefits far more from scheduling (0.751→0.624mm) than MPC does
  (0.580→0.556mm) — MPC is comparatively schedule-insensitive here, same
  qualitative direction as the rectangle, much weaker magnitude.
- Every quantitative table is regenerated directly from the saved
  `*_run_level_summary.pkl` files (single source of truth), not manually
  transcribed.
