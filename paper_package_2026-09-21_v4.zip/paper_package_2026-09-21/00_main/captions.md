# Figure and table captions (IEEE style — paste into manuscript)

Per the 2026-09-22 review: graphics carry data + concise labels only;
captions carry experimental design and interpretation.

---

**Fig. 1.** Scheduled-J performance across three path geometries.
Individual points denote live runs; bars show the run mean and error bars
the 95% CI (n=5 per controller and path). MPC achieves lower mean tracking
error with lower normalized feedback effort ($E_u$, deviation from the
feedforward reference $u_{\rm ref}$, dimensionless) and substantially less
joint-rate-constraint activity than matched-authority INV-7 on all three
geometries. The effect is large on the rectangle and smaller on the
triangle and U-shape — report as "MPC produced lower mean scheduled-J RMS
error on all three tested geometries, with a large effect on the rectangle
and smaller effects on the triangle and U-shape," not as three independent
proofs of the same effect size.

---

**Fig. 2.** Robustness to Jacobian staleness. RMS tracking error under
scheduled (valid model) and frozen (stale model, index-0 Jacobian held
fixed for the whole path) conditions, INV-7 vs MPC, one panel per geometry.
Points are individual runs (n=5); markers and error bars show mean ± 95%
CI. INV-6 (the original joint-only-feedback baseline) is omitted here and
appears only in supplementary S1, which establishes why INV-7 is used as
the baseline throughout. MPC is more robust to a frozen Jacobian on the
rectangle and triangle (FJ/SJ RMS ratio closer to 1; Table II) but on the
U-shape both attempted MPC-FJ trials developed rapidly increasing error in
the same path region and were safety-terminated before completing the
path, so no complete-path MPC-FJ metric is reported (annotated on the
panel; not a measured failure probability from n=2 attempts). Note the
wide dispersion of U-shape INV7-FJ (one of five runs reached 4.52mm while
the other four cluster at 0.84–1.56mm) — individual points are shown for
exactly this reason.

---

**Fig. 3.** Rectangle mechanism analysis, matched-authority INV-7 vs MPC
(n=5 reps each). (A, B) Mean tip-error norm vs. normalized path progress
under scheduled and frozen Jacobians respectively; shaded bands are
±1 SD across runs; gray vertical bands mark path corners. (C) For the
frozen-J condition only: $\theta_{J_y}(k)$, the rotation (deg) of the
schedule's normalized joint-to-$y$ Jacobian row from its value at $k=0$
(left axis), overlaid with the lateral-error gap
$|e_y|_{\rm INV7\text{-}FJ} - |e_y|_{\rm MPC\text{-}FJ}$ (right axis,
dotted). Because $J(0)$ is the exact (mismatched) model INV-7-FJ uses,
this rotation is a genuine measure of model staleness for that condition;
the two curves co-rise from roughly 40% path progress and both peak near
80–85%, consistent with Jacobian rotation driving INV-7's lateral failure
under a frozen model. The analogous scheduled-J panel is not shown: under
SJ, INV-7 uses $J(k)$, not $J(0)$, so rotation away from $J(0)$ is not a
model error for INV7-SJ there — at most it would indicate that harder path
regions coincide with regions of greater configuration/Jacobian variation,
not that rotation explains the SJ performance gap. (D) Directional
reliability for all four conditions (INV7/MPC × SJ/FJ): bars/left axis
show $P(\text{useful}_y>0)$, the fraction of ticks whose chosen joint
correction reduces the causally-relevant +3-step lateral error relative to
applying no new correction; diamonds/right axis show $\eta_{y,\rm net}$,
the signed aggregate net useful lateral correction (mm) per unit
normalized joint effort. Individual run values are shown for both metrics.
Under FJ, MPC's joint corrections are far more often genuinely useful
(0.82 vs 0.54) and far more effective per unit effort (0.16 vs 0.03) than
INV-7's, despite INV-7 applying comparable or larger raw joint effort — the
inverse law is not merely under-actuating laterally, its corrections are
frequently counterproductive under a stale model.

---

**Fig. 4.** Rectangle controller-mechanism ablations, both panels from
offline counterfactual replay against the same 5 recorded live
trajectories per condition (not new live trials). (A) Effect of the MPC
disturbance-persistence assumption ($\beta_d{=}0$: no persistence,
$\beta_d{=}1$: full persistence) on the causally-relevant +3-step predicted
lateral error $E_{\rm chosen,+3}$, replayed against the same 5 SJ and same
5 FJ trajectories; thin gray lines connect each individual trajectory's
paired $\beta_d{=}0\!\to\!1$ values, the bold line connects the means.
Persistence substantially improves near-term prediction quality under both
SJ (1.65→0.38mm) and FJ (4.01→0.48mm). (B) Prediction-horizon sensitivity:
median cosine agreement of the first-step joint command $u_{q,0}$ at
$N{=}3,5,10$ with its value at $N{=}15$ (left axis), and
$P(\text{useful}_y{>}0)$ at each horizon (right axis, mean ± SD over n=5).
Annotated percentages give the fraction of ticks at each horizon whose
command is *opposite-signed* relative to $N{=}15$ — 4.5% at $N{=}3$, 0.9%
at $N{=}5$, 0% at $N{\geq}10$ — which the median alone would obscure (a
reader could otherwise conclude $N{=}3$'s median agreement of 0.97 implies
essentially no difference from $N{=}15$). $N{=}5$ already closely
approximates $N{=}15$; $N{=}10$ is effectively indistinguishable from it.
Consistent with most of MPC's benefit being available already at the
minimum causal horizon ($N{=}3$ at delay $d{=}2$), with a smaller
additional gain out to $N{=}10$.

---

**Table I.** Primary result: matched-authority INV-7 vs MPC under scheduled
J, mean ± SD RMS tracking error and normalized feedback effort $E_u$
across n=5 runs per condition, all three path geometries.

**Table II.** Robustness to a frozen (stale) Jacobian: ratio of frozen-J to
scheduled-J RMS error for each controller and geometry; a ratio near 1
indicates little sensitivity to the stale model. U-shape MPC-FJ is marked
NA because both attempted trials were safety-terminated before completing
the path (see Fig. 2 and its caption).
