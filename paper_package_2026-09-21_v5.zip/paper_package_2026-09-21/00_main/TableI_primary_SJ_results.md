# Table I — Primary result: matched-authority INV-7 vs MPC, scheduled J (n=5 each)

| Shape | INV-7 RMS (mm) | MPC RMS (mm) | RMS reduction | INV-7 $E_u$ | MPC $E_u$ | Effort reduction |
|---|---:|---:|---:|---:|---:|---:|
| Rectangle | 0.784 ± 0.041 | 0.544 ± 0.016 | 30.6% | 0.625 ± 0.078 | 0.369 ± 0.038 | 41% |
| Triangle (25 mm) | 0.624 ± 0.059 | 0.556 ± 0.036 | 10.8% | 0.675 ± 0.027 | 0.282 ± 0.012 | 58% |
| U-shape | 0.560 ± 0.024 | 0.490 ± 0.017 | 12.4% | 0.606 ± 0.056 | 0.216 ± 0.012 | 64% |

Values are mean ± SD across n=5 runs. $E_u$ is the dimensionless
normalized feedback effort (S_u^-1-scaled deviation from $u_{\rm ref}$),
not millimetres. Source: `*_run_level_summary.pkl`, condition keys
`INV7-SJ` / `MPC-SJ`. Cross-referenced against Fig. 2 (same underlying
data, including the joint-rate constraint activity panel, ~16-17% INV-7 vs
~0-1% MPC on all three shapes — not repeated in this table, see Fig. 2).
